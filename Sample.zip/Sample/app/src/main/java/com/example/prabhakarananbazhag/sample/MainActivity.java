package com.example.prabhakarananbazhag.sample;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toolbar;

public class MainActivity extends Activity {
    ImageButton b1,b2,b3;

    TextView t1,t2,t3,t4,t6;
    String tip;
    EditText e1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        b1=(ImageButton)findViewById(R.id.button3);
        b2=(ImageButton)findViewById(R.id.button4);
        b3=(ImageButton)findViewById(R.id.button5);
        t1=(TextView)findViewById(R.id.textView2);
        t2=(TextView)findViewById(R.id.textView3);
        e1=(EditText)findViewById(R.id.editText);
       // t3=(TextView)findViewById(R.id.textView4);
        t6=(TextView)findViewById(R.id.textView6);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            tip="$ 10% of Bill amount";
            t1.setText(tip);
            calculate();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tip="$ 15% of Bill amount";
                t1.setText(tip);
                calculate2();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tip="$ 20% of Bill amount";
                t1.setText(tip);
                calculate3();
            }
        });
    }



    void calculate(){

      String stre1=e1.getText().toString();
      float answer1=0;
        answer1 = (Float.parseFloat(stre1)/10);
      t2.setText("$" +answer1+ "Tip Total");
      float output=0;
      output=(Float.parseFloat(stre1)+answer1);
      t6.setText("$" +output);

    }
    void calculate2(){
        String stre1=e1.getText().toString();
        float answer2=0;
        answer2 = (Float.parseFloat(stre1)/15);
        t2.setText("$" +answer2+ "Tip Total");
        float output=0;
        output=(Float.parseFloat(stre1)+answer2);
        t6.setText("$" +output);
    }
    void calculate3(){
        String stre1=e1.getText().toString();
       // float se1=0;
      //  se1=Float.parseFloat(stre1);
       // float st1=0;
       // st1=Float.parseFloat("20");
        float answer3=0;
        answer3 = (Float.parseFloat(stre1)/20);
        t2.setText("$" +answer3+ "Tip Total");
        float output=0;
        output=(Float.parseFloat(stre1)+answer3);
        t6.setText("$" +output);
    }
}
